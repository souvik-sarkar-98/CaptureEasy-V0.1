package screen.screenCapture;

import java.util.*;

import javax.swing.JOptionPane;

import java.io.*; 



public class LaunchScreenshot {
	public static void main(String args[]) throws Exception
	{
		Perform();
	}
	public static void Perform() throws Exception
	{
		if(new File(System.getProperty("user.home")+"/CapturEasy/Config/SystemPath.properties").exists())
		{
		 FileReader reader=new FileReader(System.getProperty("user.home")+"/CaptureEasy/Config/SystemPath.properties"); 
		    Properties p=new Properties();  
		    p.load(reader);  
		    if(!(p.getProperty("FilePath").equals("")))
		    {
		     
		Screenshot sc=new Screenshot();
		
		sc.setTemporaryScreenshotFolder(p.getProperty("TempPath"));
		sc.setDocumentDestinationFolder(p.getProperty("FilePath"));
		
			sc.setFrameVisibilityInScreenshot(false);
		sc.Launch();
		    }
		    else
		    {
		    	
		    }
	}
		else
		{
			try (OutputStream output = new FileOutputStream(CommonVariablesAndMethods.createFolder(System.getProperty("user.home")+"/CaptureEasy/Config")+"/SystemPath.properties")) {

	            Properties prop = new Properties();
	           
	            // set the properties value
	            prop.setProperty("FilePath", JOptionPane.showInputDialog("Enter Document Destination Path"));
	           
	           

	            // save properties to project root folder
	            prop.store(output, null);

	           

	        } catch (IOException io) {
	            io.printStackTrace();
	        }
			Perform();
			
		}
	}
}
